ScriptForge AI - Generatore di Script
====================================
Come usare:
1. Estrai lo zip
2. Apri index.html nel browser (doppio clic)
3. Funziona senza installazioni (richiede connessione per Tailwind / Prism / Lucide via CDN)

Funzioni:
- Generazione script in Roblox Luau, JavaScript, Python, PowerShell, C#, C++, SQL, HTML/CSS, Bash
- Modalita Demo senza API Key + supporto OpenAI / Gemini con API Key
- Account: Crea Account / Accedi / Profilo
- Cronologia personale, Copia, Download file
